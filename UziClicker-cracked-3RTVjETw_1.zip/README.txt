cracked by austria rodeo hacking boys
jak odpalacie na windowsie 11 (nie wiem jak na 10) to musicie z 3 razy kliknac w plik wykonywalny
aby crack zadzialal, enjoy